import React, { useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./Components/login";
import Register from "./Components/register";
import Course from "./Components/course";
import Courses from "./Components/Courses";
import Profile from "./Components/profile";
import Learnings from "./Components/learnings";
import Home from "./Components/Home";
import AddCourse from "./Components/AddCourse";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Dashboard from "./Components/DashBoard/Dashboard";
import "boxicons/css/boxicons.min.css";
import EditCourse from "./Components/EditCourses";
import DUsers from "./Components/DashBoard/DUsers";
import DCourses from "./Components/DashBoard/DCourses";
import Assessment from "./Components/Assessment";
import ErrorPage from "./Components/ErrorPage";
import AddQuestions from "./Components/AddQuestions";
import Performance from "./Components/DashBoard/Performance";
import DTutors from "./Components/DashBoard/DTutors";
import certificate from "./Components/certificate";
import Forum from "./Components/forum";
import { ChatBotWidget } from "chatbot-widget-ui";
import ChatBubble from "./Components/ChatBubble.jsx";
import ReactMarkdown from 'react-markdown';

function App() {
  const [messages, setMessages] = useState([]);

  const customApiCall = async (message) => {
    const { GoogleGenerativeAI } = require("@google/generative-ai");

    const genAI = new GoogleGenerativeAI(
      "AIzaSyAbu7LX_04WZoaE3IWFGbwL1NptFVpwg4o"
    );
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });

    const prompt = message;

    const result = await model.generateContent(prompt);
    return result.response.text();
  };

  const handleBotResponse = (response) => {
    // Handle the bot's response here
    console.log("Bot Response:", response);
    setMessages((prevMessages) => [
      ...prevMessages,
      { role: "assistant", content: <ReactMarkdown>{response}</ReactMarkdown> },
    ]);
  };

  const handleNewMessage = (message) => {
    setMessages((prevMessages) => [...prevMessages, message]);
  };

  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/addquestions/:id" element={<AddQuestions />} />
          <Route path="/dashboard" Component={Dashboard}></Route>
          <Route path="/login" Component={Login}></Route>
          <Route path="/register" Component={Register}></Route>
          <Route path="/" Component={Home}></Route>
          <Route path="/courses" Component={Courses}></Route>
          <Route path="/course/:id" Component={Course}></Route>
          <Route path="/discussion/:id" Component={Forum}></Route>
          <Route path="/certificate/:id" Component={certificate}></Route>
          <Route path="/assessment/:id" Component={Assessment}></Route>
          <Route path="/addcourse" Component={AddCourse}></Route>
          <Route path="/editCourse/:id" Component={EditCourse}></Route>
          <Route path="/profile" Component={Profile}></Route>
          <Route path="/Learnings" Component={Learnings}></Route>
          <Route path="/Dcourses" Component={DCourses}></Route>
          <Route path="/Dusers" Component={DUsers}></Route>
          <Route path="/Dtutors" Component={DTutors}></Route>
          <Route path="/Performance" Component={Performance} />
          <Route path="*" Component={ErrorPage}></Route>
        </Routes>
      </BrowserRouter>
      <ChatBotWidget
        callApi={customApiCall}
        onBotResponse={handleBotResponse}
        handleNewMessage={handleNewMessage}
        messages={messages}
        primaryColor="#0047ca"
        inputMsgPlaceholder="Type your message..."
        chatbotName="Chatbot"
        isTypingMessage="Typing..."
        IncommingErrMsg="Oops! Something went wrong. Try again."
        botIcon={
          <div style={{ backgroundColor: "#888", borderRadius: "10%" }}>
            <ChatBubble />
          </div>
        }
        botFontStyle={{
          fontFamily: "Arial",
          fontSize: "14px",
          color: "white",
        }}
        typingFontStyle={{
          fontFamily: "Arial",
          fontSize: "12px",
          color: "#888",
          fontStyle: "italic",
        }}
        chatIcon={<ChatBubble />}
      />
      <ToastContainer />
    </div>
  );
}

export default App;
