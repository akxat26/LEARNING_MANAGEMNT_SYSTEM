function Navbar(){
    return(
        <nav>
          <i className='bx bx-menu' ></i>
          <h4>Menu</h4>
          <form action="#">
            <div className="form-input">
            </div>
          </form>
        </nav>
    );
}

export default Navbar;